INSERT INTO employees(name, dept_id, salary) VALUES('Varsha', 2, 60000);
UPDATE employees SET salary=salary+5000 WHERE id=10;
DELETE FROM employees WHERE id=15;