SELECT * FROM employees;

SELECT name, salary FROM employees WHERE salary > 50000;